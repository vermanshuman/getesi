package it.nexera.ris.common.enums;

public enum AgencyType {
    OFFICE, FILIAL;
}
