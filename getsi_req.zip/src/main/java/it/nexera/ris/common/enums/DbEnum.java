package it.nexera.ris.common.enums;

public interface DbEnum {
    public String getRealName();

    public Object getRealObject();
}
