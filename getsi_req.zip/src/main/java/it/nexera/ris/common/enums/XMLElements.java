package it.nexera.ris.common.enums;

public interface XMLElements {
    public String getElement();
}
