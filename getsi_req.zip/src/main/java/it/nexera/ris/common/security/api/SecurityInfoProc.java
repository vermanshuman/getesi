package it.nexera.ris.common.security.api;

import java.util.List;

public interface SecurityInfoProc {
    public List<String> procSecurityInfo(SecurityInfo si);

}
