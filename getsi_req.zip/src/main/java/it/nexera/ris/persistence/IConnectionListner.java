package it.nexera.ris.persistence;

public interface IConnectionListner {
    public void fireConnetionEstablished();

    public void fireConnetionResufed();
}
