package it.nexera.ris.persistence;

public interface IConnectionManager {
    public void handleConfigFileChange();
}
