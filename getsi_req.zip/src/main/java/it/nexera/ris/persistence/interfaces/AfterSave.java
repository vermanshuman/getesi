package it.nexera.ris.persistence.interfaces;

public interface AfterSave {
    void afterSave();
}
