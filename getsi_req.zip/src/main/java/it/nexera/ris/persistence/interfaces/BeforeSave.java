package it.nexera.ris.persistence.interfaces;

public interface BeforeSave {
    void beforeSave();
}
